def passthrough():
    return True    

class DecisionTree():
    def __init__(self, trueact=None, condition=passthrough, falseact=None):
        self.condition = condition
        self.trueact = trueact
        self.falseact = falseact
        
    def setCondition(self, condition):
        self.condition = condition
            
    def setTrueact(self, trueact):
        self.trueact = trueact
    
    def setFalseact(self, falseact):
        self.falseact = falseact
        
    def getDecision(self, **params):
        if self.falseact == None:
            return self.trueact
        if self.condition(params['ifparams']):
            try:return self.trueact.getDecision(params['trueparams'])
            except:return self.trueact.getDecision(ifparams=params['ifparams'])
        else:
            try:return self.falseact.getDecision(params['falseparams'])
            except:return self.falseact.getDecision(ifparams=params['ifparams'])
