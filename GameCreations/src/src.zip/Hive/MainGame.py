import pygame
import Engine.Base as Base
from Engine.Game import Game
from Engine.Menu import Menu, MenuItem
from Engine.GameElements import GameplayObjects, GameSprite, GameObject, AnimationList
from pygame.locals import *
from Swarmer import Swarmer
from World import World
import math
import random

class HiveGame(Game):
    def __init__(self):
        Game.__init__(self, "Hive", True, (0,0,0), (800,600))
        self.Menu = HiveMenu(self.screen)
    
    def Settings(self):
        """Settings operations here: Manipulate menu handlers"""
    def LoadGame(self):
        """Menu handlers for load game menu""" 
    def HandleMenuEvent(self, menuEvent):
        if menuEvent == True:
            return True
        if menuEvent == False:
            return False
        if menuEvent == "Exit":
            return False
        if menuEvent == "Continue":
            self.unPauseGame()
            self.Menu.Deactivate()
            return True
        if menuEvent == "NewGame":
            self.unPauseGame()
            self.Init()
            self.Menu.Deactivate()
            return True
        if menuEvent == "Load":
            self.LoadGame()
        if menuEvent == "Settings":
            self.Settings()
        return True
    
    def HandleGameEvent(self, event):
        if event.type == QUIT:
            print "Requesting quit"
            return False    
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                self.PauseGame()
                print "Pausing and navigating to menu"
                self.Menu.Activate()
                return True
            if event.key == K_SPACE:
                if self.Paused:
                    self.unPauseGame()
                else:
                    self.PauseGame(False)
        if not self.Paused:
            for swarmer in self.Get("swarmers").GetAll():
                if swarmer.ClickEvent(event):
                    print "Clicked on swarmer", swarmer.Name
        return True
    
    def Init(self):
        if hasattr(self,"world"):
            del self.world
        if hasattr(self,"Swarmers"):
            del self.Swarmers
        Game.Init(self)
        self.clockrate = 60
        Base.set_resource_path('Resources')
        offscreen = self.screen.get_size()
        self.initSwarmers(2,10)
        self.AddFeature("World", self.world)
        self.AddFeature("swarmers", self.Swarmers)
        
    def initSwarmers(self,teams,number):
        self.world = World()
        self.Swarmers = GameplayObjects(self.screen)
        for i in range(teams*number):
            team = i%teams
            N = i/teams
            new = Swarmer("S"+str(team)+str(N), self.screen, team, (250+team*100,250+N*20), 500)
            new.setWorld(self.world)
            self.Swarmers.Add(new)
        self.world.addUnits(self.Swarmers.GetAll())

class HiveMenu(Menu):
    def __init__(self, surface):
        Menu.__init__(self, surface, [], "Hive Mind: Main Menu", Nshown = 5)
        self.AddMenuItem(MenuItem("New Game", (0, 255, 0), "NewGame"))
        self.AddMenuItem(MenuItem("Resume Game", (0, 255, 0), "Continue"))
        self.AddMenuItem(MenuItem("Load Game", (0, 255, 0), "Load"))
        self.AddMenuItem(MenuItem("Settings", (0, 255, 0), "Settings"))
        self.AddMenuItem(MenuItem("Exit", (0, 255, 0), "Exit"))
        self.Highlight(0)

def LaunchGame():
    print "Launching Hive!..."
    game = HiveGame()
    game.RunGame()
    
if __name__ == "__main__":
    LaunchGame()