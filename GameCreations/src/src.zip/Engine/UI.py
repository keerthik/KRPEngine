from GameElements import GameObject
import pygame, Base
from pygame.locals import *

TOP = 0
RIGHT = 1
BOT = 2
LEFT = 3 

class UI:
    def __init__(self, surface):
        self.screen = surface

        self.TOPLEFT = (0,0)
        self.BOTRIGHT = self.screen.get_size()
        self.TOPRIGHT = (self.BOTRIGHT[0], self.TOPLEFT[1])
        self.BOTLEFT = (self.TOPLEFT[0], self.BOTRIGHT[1])

        self.UIsprites = pygame.sprite.OrderedUpdates()
        
        self.ToolItem = None
        self.ToolTipBox = pygame.Surface((0,0)).convert()
        self.UIdict = {}
    
    def SetOnClick(self, uiitemName, onclick, params = None):
        self.UIdict[uiitemName].SetOnClick(onclick)
        
    def AddItem(self, *uiitems):
        try:
            self.UIsprites.add(*uiitems)
            for uiitem in uiitems:
                self.UIdict[uiitem.Name] = uiitem
        except:
            print "Unable to add game object or game object list"
        
    def update(self):
        self.UIsprites.update()
        for uiitem in self.UIdict.values():
            uiitem.Update()
        return True
    
    def draw(self):
        self.UIsprites.draw(self.screen)
        self.blitToolTip()
        return True

    def MakeUI(self, items, location = TOP, padding = 5):
        if location == TOP:
            position = list(self.TOPLEFT)
            operation = '+'
        elif location == RIGHT:
            position = list(self.TOPRIGHT)
            operation = '+'
        elif location == BOT:
            position = list(self.BOTLEFT)
            operation = '-'
        elif location == LEFT:
            position = list(self.TOPLEFT)
            operation = '+'
        
        position = Base.tuple_add(position, (padding, -padding))
        for item in items:
            position = Base.tuple_add(position, (padding, -item.Sprite.rect.height))
            item.Reposition(position)
            position = Base.tuple_add(position, item.Sprite.rect.size)

    def blitToolTip(self):
        """Check if a tooltip is expected and draw it"""
        if not pygame.font or self.ToolItem == None:
            self.ToolTipBox = pygame.Surface((0,0)).convert()
            return True
        elif self.ToolItem.DrawToolTip:
            fontsize = 20
            self.screen.blit(self.ToolTipBox, Base.tuple_add(self.ToolItem.Sprite.rect.topleft,(10,fontsize+5), '-'))
            return False
    
    def HandleEvents(self, event):
        UIreturn = None
        for uiitem in self.UIdict.values():
            if uiitem.DrawToolTip:
                self.ToolTipBox = uiitem.ToolTipBox
                self.ToolItem = uiitem
            try:
                if uiitem.ClickEvent(event):
                    UIreturn = uiitem.OnClick()
            except:
                """no click event defined"""
            try:
                if uiitem.DragEvent(event):
                    UIreturn = uiitem.OnDrag()
                    return UIreturn
            except:
                """no drag event defined"""
        return UIreturn
    
    def GetUIdict(self):
        return self.UIdict
    
    def GetUIitems(self):
        return self.UIdict.values()        

    def GetUIsprites(self):
        return self.UIsprites

class UIitem(GameObject):
    def __init__(self, Name, screen, base_image, position = (0,0)):
        GameObject.__init__(self, Name, screen, base_image, position)
        self.ToolTip = None
        self.ReturnString = None
        self.ShowTip = False
        self.DrawToolTip = False
        self.ToolTipBox = None
        
    def OnClick(self):
        return self.ReturnString

    def SetOnClick(self, ReturnString):
        self.ReturnString = ReturnString
            
    def OnMouseOver(self):
        if self.ShowTip:
            if not self.DrawToolTip:
                self.ToolTipBox = self.RenderToolTip()
            self.DrawToolTip = True
        else:
            self.DrawToolTip = False

    def RenderToolTip(self):
        if self.ToolTip == None:
            return False
        fontsize = 20
        font = pygame.font.Font(None, fontsize)
        text = font.render(self.ToolTip, 1, (250, 250, 250))
        hoverBox = pygame.Surface(Base.tuple_add(text.get_rect()[2:],(fontsize,6))).convert()
        hoverBox.fill((0,100,200))
        textpos = text.get_rect(centerx=hoverBox.get_width()/2, centery=hoverBox.get_height()/2)
        hoverBox.blit(text, textpos)
        return hoverBox
    
    def SetToolTip(self, text, showOnHover = True):
        self.ToolTip = text
        if showOnHover:
            self.ShowTip = True
            
    def Update(self):
        self.DrawToolTip = False
        if self.CursorOver():
            self.OnMouseOver()
        return GameObject.Update(self)

class UIDraggable(UIitem):
    def __init__(self, Name, screen, base_image, relative_pos = (0, 0), position = (0,0)):
        UIitem.__init__(self, Name, screen, base_image, position)
        self.Dragged = False
        self.Snap = False
        self.Relative = relative_pos
        
    def CursorLatch(self):
        self.Dragged = True
        self.Sprite.Reposition(Base.tuple_add(pygame.mouse.get_pos(), self.Relative))
    
    def CursorDetach(self, detach_axn = None, *argsv):
        self.Dragged = False
        if self.Snap:
            return self.SnapTo()
        if detach_axn != None:
            return detach_axn(*argsv)
        
    def SetSnapTo(self, rects, Snap = True):
        self.SnapRects = rects
        self.Snap = Snap
        
    def SnapTo(self):
        for rect in self.SnapRects:
            if pygame.sprite.collide_rect(self.Sprite, rect):
                self.Reposition(rect.topleft)
                return True
        return False

    def DragEvent(self, event):
        if self.CursorOver():
            if event.type == MOUSEBUTTONDOWN:
                self.CursorLatch()
                return True
            if event.type == MOUSEBUTTONUP:
                self.CursorDetach()
                return True   
        return False
    
    def OnDrag(self):
        return True
    
    def Update(self):
        if self.Dragged:
            self.CursorLatch()
        return GameObject.Update(self)