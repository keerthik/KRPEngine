import Base
import pygame
from pygame.locals import *
from Menu import Menu

class Game:
    def __init__(self, name = 'UnnamedGame', mouse_exists = True, bgcolor = (0, 0, 0), DISP_SIZE = (0,0)):
        self.Name = name
        self.BGcolor = bgcolor
        self.Mouse = mouse_exists
        if DISP_SIZE == (0, 0):
            self.DISP_SIZE = Base.DISP_SIZE
        else:
            self.DISP_SIZE = DISP_SIZE
        self.PreInit()
        self.Menu = Menu()
        self.Paused = False

    def AddFeature(self, objectName, gameObject):
        try:
            self.GameFeatures[objectName] = gameObject
        except:
            print "Unable to add game object "+objectName
        
    def Get(self, FeatureName):
        return self.GameFeatures[FeatureName]
    
    def PauseGame(self, menu = True):
        self.PausedObjects = self.GameFeatures
        self.Paused = True
        if menu:
            self.Menu.Activate()
            self.GameFeatures = self.MenuObjects
        else:
            self.GameFeatures = {}
        
    def unPauseGame(self):
        self.Paused = False
        self.GameFeatures = self.PausedObjects
        self.PausedObjects = {}
        
    def RunGame(self):
        self.Init()
        self.Loop()
        self.Terminate()

    def PreInit(self):
        self.screen = pygame.display.set_mode(self.DISP_SIZE)
        pygame.display.set_caption(self.Name)
        pygame.mouse.set_visible(self.Mouse)
        self.background = pygame.Surface(self.screen.get_size())
        self.background.fill(self.BGcolor)
        self.background = self.background.convert()
        self.clock = pygame.time.Clock()
        pygame.init()
        pygame.font.init()
        print "Initialized"
        
    def Init(self):
        """Custom init for the game"""
        self.clockrate = 60
        self.MenuObjects = {"Menu":self.Menu}
        self.PausedObjects = {}
        self.GameFeatures = {}

        return True
    #============================================================================================    
    def Loop(self):    
        RunLoop = True
        while(RunLoop == True):    
            EventRunLoop = self.UserEventHandle()
            UpdateRunLoop = self.Update()
            DrawLoop = self.Draw()
            RunLoop = EventRunLoop and UpdateRunLoop and DrawLoop

    def UserEventHandle(self):
        EventRunLoop = True
        for event in pygame.event.get():
            EventRunLoop = (EventRunLoop and self.HandleEvent(event))
        return EventRunLoop
    
    def Update(self):
        self.clock.tick(self.clockrate)
        UpdateRunLoop = True
        UpdateRunLoop = self.UpdateGameObjects()
        return UpdateRunLoop

    def Draw(self):
        DrawRunLoop = self.DrawGameObjects()
        pygame.display.flip()
        self.screen.blit(self.background, (0, 0))
        return DrawRunLoop
    
    def HandleEvent(self, event):
        if self.Menu.isActive():
            menuEvent = self.Menu.HandleEvent(event)
            return self.HandleMenuEvent(menuEvent)
        else:
            return self.HandleGameEvent(event)

    def HandleMenuEvent(self, menuEvent):
        if menuEvent == True:
            return True
        if menuEvent == False:
            return False
        if menuEvent == "Exit":
            return False
        if menuEvent == "Continue":
            self.unPauseGame()
            self.Menu.Deactivate()
            return True
        if menuEvent == "NewGame":
            self.unPauseGame()
            self.Menu.Deactivate()
            self.Init()
            return True

    def HandleGameEvent(self, event):
        """Overwrite with function to handle all in-game events"""    
        if event.type == QUIT:
            print "Requesting quit"
            return False         
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                self.PauseGame()
                print "Pausing and navigating to menu"
                self.Menu.Activate()
                return True
        return True
            
    def UpdateGameObjects(self):
        """ This function updates all the game objects. The game objects should have their
            own definition for "update". These update functions should return true or false
        """
        UpdateRunLoop = True
        for game_object in self.GameFeatures.values():
            objectRunLoop = game_object.update()
            if type(objectRunLoop) != type(True):
                raise ValueError('Game Object Update function has not specified boolean return')
            else:
                UpdateRunLoop = UpdateRunLoop and objectRunLoop
        return UpdateRunLoop

    def DrawGameObjects(self):
        DrawRunLoop = True
        for game_object in self.GameFeatures.values():
            if game_object != None:
                objectRunLoop = game_object.draw()
                if type(objectRunLoop) != type(True):
                    raise ValueError('Game Object Draw function has not specified boolean return')
                else:
                    DrawRunLoop = DrawRunLoop and objectRunLoop
        return DrawRunLoop
            
    #============================================================================================    
    def Terminate(self):
        print "Terminating Game"
        pygame.font.quit()
        pygame.quit()
        Base.Exit()
#================================================================================================
    
if __name__ == "__main__":
    TestGame = Game(name = 'TestGame', DISP_SIZE = (500, 500))
    TestGame.RunGame()